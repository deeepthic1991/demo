package com.java.spring.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.java.spring.model.Employee;

public class EmployeeDAOJdbc implements IEmployeeDAO {

	private JdbcTemplate jdbcTemplate;
	private PlatformTransactionManager transactionManager;

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public void setTransactionManager(
			PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

	@Override
	public List<Employee> getEmployees() {
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);

		List<Employee> employees = null;
		try {
			employees = jdbcTemplate.query("select * from employee",
					new RowMapper<Employee>() {
						public Employee mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							Employee emp = new Employee();
							emp.setEmployeeId(rs.getInt("employeeId"));
							emp.setAge(rs.getInt("age"));
							emp.setCity(rs.getString("city"));
							emp.setDeptId(rs.getInt("deptId"));
							emp.setAddress(rs.getString("address"));
							emp.setFirstName(rs.getString("firstName"));
							emp.setLastName(rs.getString("lastName"));
							return emp;
						}
					});

		} catch (DataAccessException e) {
			e.printStackTrace();
			transactionManager.rollback(status);
		}
		transactionManager.commit(status);
		return employees;
	}

	@Override
	public void add(Employee emp) {
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(def);
		try {
			String sql = "insert into employee (age, deptId, lastName, firstName, address, city) VALUES (?, ?, ?, ?, ?, ?)";

			jdbcTemplate.update(
					sql,
					new Object[] { emp.getAge(), emp.getDeptId(),
							emp.getLastName(), emp.getFirstName(),
							emp.getAddress(), emp.getCity() });
			
		} catch (DataAccessException e) {
			transactionManager.rollback(status);
			throw e;
		}
		transactionManager.commit(status);
	}

	@Override
	public void update(Employee employee) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Employee getEmployee(int employeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(int employeeId) {
		// TODO Auto-generated method stub
		
	}

}
