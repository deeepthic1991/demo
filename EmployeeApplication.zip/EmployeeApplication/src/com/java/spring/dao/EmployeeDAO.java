package com.java.spring.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.java.spring.model.Employee;

public class EmployeeDAO implements IEmployeeDAO {

	private Logger logger = Logger.getLogger(EmployeeDAO.class);
	private SessionFactory sessionFactory;

	public EmployeeDAO(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Employee> getEmployees() {
		Session session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		List<Employee> employees = null;
		try {
			System.out.println("IN LIST");
			employees = (List<Employee>) session.createQuery("from Employee")
					.list();

		} catch (HibernateException e) {
			logger.error("Error while getting the Employees");
			// e.printStackTrace();
			session.getTransaction().rollback();
		}
		session.getTransaction().commit();
		return employees;
	}

	@Override
	public void add(Employee emp) {
		Session session = sessionFactory.getCurrentSession();
		try {
			session.beginTransaction();
			session.save(emp);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			// e.printStackTrace();
			logger.error("Error while adding the Employee"
					+ emp.getEmployeeId());
			session.getTransaction().rollback();
		}
	}

	@Override
	public void update(Employee employee) {

		Session session = sessionFactory.getCurrentSession();
		try {
			System.out.println("IN Update");
			session.beginTransaction();
			session.saveOrUpdate(employee);
		//testing:	throwException();
			session.getTransaction().commit();
		} catch (Exception e) {
			logger.error("Error while updating the Employee"
					+ employee.getEmployeeId());
			logger.error("Transaction rolling back");
			// e.printStackTrace();
			session.getTransaction().rollback();
		}
		
	}
	
	void throwException(){
		Employee emp = null;
		if(emp.getAddress()=="abc"){
			//do something
		}
	}

	@Override
	public Employee getEmployee(int id) {
		Session session = sessionFactory.getCurrentSession();
		Employee employee = null;
		try {
			System.out.println("IN GetIteam");
			session.beginTransaction();
			employee = (Employee) session.get(Employee.class, id);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			logger.error("Error while getting the Employee" + id);
			// e.printStackTrace();
			session.getTransaction().rollback();
		}
		return employee;
	}

	@Override
	public void delete(int id) {
		Session session = sessionFactory.getCurrentSession();
		try {
			session.beginTransaction();
			Employee emp = (Employee) session.get(Employee.class, id);
			if (null != emp) {
				session.delete(emp);
			}
			session.getTransaction().commit();
		} catch (HibernateException e) {
			logger.error("Error while deleting the Employee" + id);
			// e.printStackTrace();
			session.getTransaction().rollback();
		}
	}
}
