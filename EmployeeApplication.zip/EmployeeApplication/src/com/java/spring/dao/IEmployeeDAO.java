package com.java.spring.dao;

import java.util.List;

import com.java.spring.model.*;
public interface IEmployeeDAO {
	public List<Employee> getEmployees();
	public void add(Employee employee);
    public void  update(Employee employee);
    public Employee  getEmployee(int employeeId);
    public void  delete(int employeeId);
}
