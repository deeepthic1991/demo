package com.java.spring.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.*;

import com.java.spring.dao.IEmployeeDAO;
import com.java.spring.model.Employee;
@Controller
public class EmployeeController {
	 private Logger logger = Logger.getLogger(EmployeeController.class);
     
	 @Autowired
	    private IEmployeeDAO employeeDao; 
	 
	      @RequestMapping(value="/listEmployee")
	        public ModelAndView list() {
	            List<Employee> empList = employeeDao.getEmployees();
	            ModelAndView model = new ModelAndView("listEmployee");
	            model.addObject("empList", empList);
	            return model;
	        }
	      
	      @RequestMapping(value="/loadEmployee")
	        public ModelAndView add() {
	            ModelAndView model = new ModelAndView("loadEmployee");
	           Employee employee=new Employee();
	           model.addObject("employee", employee);
	            List<Employee> empList = employeeDao.getEmployees();
	            model.addObject("empList", empList);
	            logger.debug("Inside load employees ************************");
	            return model;
	        }
	 
	     @RequestMapping(value="/editEmployee")
	        public ModelAndView edit(@RequestParam(value="employeeId", required=true) int employeeId) {
	          System.out.println("Id= " + employeeId);
	            ModelAndView model = new ModelAndView("loadEmployee");
	           Employee employee=  employeeDao.getEmployee(employeeId);
	           model.addObject("employee", employee);
	           List<Employee> empList = employeeDao.getEmployees();
	            model.addObject("empList", empList);
	            return model;
	        }
	 
	      @RequestMapping(value="/deleteEmployee")
	        public ModelAndView delete(@RequestParam(value="employeeId", required=true) int employeeId) {
	            ModelAndView model = new ModelAndView("loadEmployee");
	            employeeDao.delete(employeeId);
	           List<Employee> empList = employeeDao.getEmployees();
	            model.addObject("empList", empList);
	            return model;
	        }
	 
	      @RequestMapping(value = "/saveEmployee", method = RequestMethod.POST)
	        public ModelAndView save(@ModelAttribute("employee") Employee employee) {
	            System.out.println(employee.getFirstName());
	            if(null != employee )
	                employeeDao.add(employee);
	 
	            ModelAndView model = new ModelAndView("loadEmployee");
	            employee=new Employee();
	            model.addObject("employee", employee);
	            List<Employee> empList = employeeDao.getEmployees();
	            model.addObject("empList", empList);
	            return model;
	      }
	 
	      @RequestMapping(value = "/updateEmployee", method = RequestMethod.POST)
	        public ModelAndView update(@ModelAttribute("employee") Employee employee) {
	            System.out.println(employee.getFirstName());
	            if(null != employee )
	                employeeDao.update(employee);
	 
	            ModelAndView model = new ModelAndView("loadEmployee");
	            employee=new Employee();
	            model.addObject("employee", employee);
	            List<Employee> empList = employeeDao.getEmployees();
	            model.addObject("empList", empList);
	            return model;
	      }
	      
	      @RequestMapping(value = "/searchEmployee", method = RequestMethod.POST)
	        public ModelAndView search(@ModelAttribute("employeeSearch") Employee employee) {
	    	  Employee object = null;
	            if(null != employee )
	            	object  =    employeeDao.getEmployee(employee.getEmployeeId());
	 
	            ModelAndView model = new ModelAndView("loadEmployee");
	            employee=new Employee();
	            model.addObject("employee", employee);
	            List<Employee> empList = new ArrayList<Employee>();
	            empList.add(object);
	            model.addObject("empList", empList);
	            return model;
	      }
	 
}
